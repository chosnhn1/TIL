# Vi & Vim

> Vi Improved

["Vim in 100 Seconds" by Fireship](https://youtu.be/-txKSRn0qeA)


Quick Commands

* `:q` `:q!` `:qw`
* `h j k l`:  move
* `v`: visual mode
* `x`: delete a letter
* `dd`: delete line
* `u`: undo
* `:set number`:  move to 
* `:2`: set number
* `i`: insert mode
* `esc `: return to normal mode
* `+p`: paste
* `:w` : write
* `:!`: run command


